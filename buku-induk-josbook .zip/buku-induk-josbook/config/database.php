<?php
return [
    'driver' => 'mysql',
    'host' => '127.0.0.1',
    'port' => 3306,
    'database' => 'buku_induk_josbook',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8mb4',
];
