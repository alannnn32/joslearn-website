<?php
// Daftar route web: login, logout, dashboard, dan fitur berdasarkan role.
