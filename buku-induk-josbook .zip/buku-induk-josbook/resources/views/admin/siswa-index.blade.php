<?php
// TODO: Implementasikan siswa-index.blade.php.
