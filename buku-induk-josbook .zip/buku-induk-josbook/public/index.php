<?php
// Front controller aplikasi Buku Induk JosBook.
// Routing dan bootstrap aplikasi akan dihubungkan pada tahap implementasi.
