# Buku Induk JosBook

Struktur folder awal sesuai rancangan proyek.

## Catatan
- ZIP ini berisi kerangka folder dan file placeholder, belum merupakan aplikasi yang siap dijalankan.
- Struktur menggunakan penamaan view `.blade.php`, tetapi belum disertai Laravel/Blade runtime.
- Untuk menjalankan aplikasi secara nyata, perlu ditambahkan bootstrap/autoload, router, koneksi database, implementasi controller/model, serta mekanisme render view.
- Sesuaikan pengaturan database pada `config/database.php` sebelum integrasi MySQL.

