<?php
// TODO: Implementasikan 2026_01_01_000001_create_sekolah_tables.php.
