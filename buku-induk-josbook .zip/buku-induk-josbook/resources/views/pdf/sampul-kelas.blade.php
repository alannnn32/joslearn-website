<?php
// TODO: Implementasikan sampul-kelas.blade.php.
