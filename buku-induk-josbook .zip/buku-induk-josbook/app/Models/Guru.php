<?php
// TODO: Implementasikan Guru.php.
