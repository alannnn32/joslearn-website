<?php
// TODO: Implementasikan 2026_01_01_000002_create_guru_tables.php.
