<?php
// TODO: Implementasikan GuruMiddleware.php.
