<?php
// TODO: Implementasikan 2026_01_01_000004_create_akademik_tables.php.
