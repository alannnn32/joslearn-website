<?php
return [
    'name' => 'Nama Sekolah',
    'npsn' => '',
    'address' => '',
];
