<?php
// TODO: Implementasikan guru-index.blade.php.
