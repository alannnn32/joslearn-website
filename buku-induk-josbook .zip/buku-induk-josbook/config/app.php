<?php
return [
    'name' => 'Buku Induk JosBook',
    'env' => 'local',
    'debug' => true,
    'url' => 'http://localhost/buku-induk-josbook/public',
];
