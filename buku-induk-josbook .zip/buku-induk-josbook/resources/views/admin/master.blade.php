<?php
// TODO: Implementasikan master.blade.php.
